#include <stdio.h>
#include <stdlib.h>
#include <string.h>





void printaProcessos(int  maxProcessos, int tabela[2][20]){
    printf("\n\n\t\t\tTempo\t\tChegada\n");
    for(int i = 0; i < maxProcessos; i++){
        printf("Processo %i:\t\t%i\t\t%i\n", i, tabela[0][i], tabela[1][i]);
    }
}




int main() {
    const char *nomeArquivo = "teste.csv";
    FILE *arquivo = fopen(nomeArquivo, "r");
   
    if (arquivo == NULL) {
        printf("Não foi possível abrir o arquivo %s\n", nomeArquivo);
        return 1;
    }
    
    //inicia variaveis
    char linha[256]; 
    char *token;
    int maxProcessos = 0;
    int tabela[2][20];


    // Lê cada linha do arquivo CSV
    for (int i = 0; fgets(linha, sizeof(linha), arquivo) != NULL; i++) {
        // Divide a linha em campos usando a vírgula como delimitador
        token = strtok(linha, ",");
        tabela[0][i] = atoi(token);

        token = strtok(NULL, ",\n");
        tabela[1][i] = atoi(token);

        maxProcessos++;
    }

    //printa os processos, tempos e chegadas
    printaProcessos(maxProcessos, tabela);

    //define quanto de tempo passar para calcular os processos
    int tempoMax = 0;
    for (int i = 0; i < maxProcessos; i++){
        tempoMax += tabela[0][i];
    }

    printf("\nTempo total: %is\n\n", tempoMax);

    int stackProcesso[2000];
    int stackPointer = 0;
    stackProcesso[0] == -1;

    
//////////////////// daqui pra baixo nao funfa direito


    int processoSelecionado;
    for(int tempoAtual = 0; tempoAtual < tempoMax; tempoAtual++){
        for (int i = 0; i < maxProcessos; i++){
            if (tabela[1][i] == tempoAtual){
                stackProcesso[stackPointer] = processoSelecionado;
                stackPointer++;
                processoSelecionado == i;
                break;
            }
        }

        for(int i = 0; i <= stackPointer; i++){
            printf("%i, ", stackProcesso[i]);
        }
        printf("\n");

    /*
    //codigo bugado
        if (tabela[0][processoSelecionado] >= 1){
            tabela[0][processoSelecionado]--;
            printf("%i", processoSelecionado);
        }
        else{
            if (stackProcesso[stackPointer - 1] == -1){
                break;
            }
            else{
                stackPointer--;
                processoSelecionado == stackProcesso[stackPointer];
            }
        }
    */
    }

    



    fclose(arquivo);
    return 0;
}


