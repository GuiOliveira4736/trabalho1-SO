
//-------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



void printaProcessos(int maxProcessos, int tabela[2][maxProcessos]){
    printf("\nQUANTIDADE DE PROCESSOS SOBRE ANALISE: %d\n",maxProcessos);
       printf("\t\t");
          for(int i = 0; i < maxProcessos; i++){
         printf("%c\t",'A' + i);
          }
          printf("\n");
    for(int i = 0; i < 2; i++){
        if(i==0){
        printf("TEMPO\t");
        }else{
               printf("CHEGADA\t");
        }
        for (int j = 0;j<maxProcessos;j++){
        printf("%d\t", tabela[i][j]);

    }
    printf("\n");
}

}




int main() {
    const char *nomeArquivo = "teste.csv";
    FILE *arquivo = fopen(nomeArquivo, "r");
   
    if (arquivo == NULL) {
        printf("Não foi possível abrir o arquivo %s\n", nomeArquivo);
        return 1;
    }
    char linha[256];
    char *token;
    int maxProcessos = 0;
    int maxColunas = 0;

    // Primeira passagem para determinar o número máximo de colunas
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        int coluna = 0;

        token = strtok(linha, ",");
        while (token != NULL) {
            coluna++;
            token = strtok(NULL, ",\n");
        }

        if (coluna > maxColunas) {
            maxColunas = coluna;
        }
    }

    // Aloca dinamicamente a matriz com base no número máximo de colunas
    int tabela[2][maxColunas];

    // Retorna ao início do arquivo
    fseek(arquivo, 0, SEEK_SET);
  // Lê o arquivo linha por linha
    for (int linhaAtual = 0; fgets(linha, sizeof(linha), arquivo) != NULL; linhaAtual++) {
        int coluna = 0;

        // Divide a linha em campos usando a vírgula como delimitador
        token = strtok(linha, ",");

        while (token != NULL) {
            if (coluna < 20) { // Limite de 20 colunas
                tabela[linhaAtual][coluna] = atoi(token);
                token = strtok(NULL, ",");
                coluna++;
            } else {
                printf("Excedeu o limite de colunas (20) na linha %d.\n", linhaAtual);
                break;
            }
        }

        if (coluna > maxColunas) {
            maxColunas = coluna;
        }
    }

    maxProcessos = maxColunas; // Número de colunas é igual ao número de processos
         
        printaProcessos(maxProcessos,tabela);
//---------------------------------------------------------------------         
//FILA DE TEMPO
//menor tempo cpu
int menor_tempo = 99;
for(int j=0;j<maxProcessos;j++){
if(menor_tempo>tabela[0][j])
menor_tempo=tabela[0][j]; 
}

//menor chegada
int menor_chegada = 0;
printf("|0|");
for(int j=0;j<maxProcessos;j++){
if(menor_chegada==tabela[1][j]){
    for(int aux=0;aux<maxProcessos;aux++){
        
if(tabela[0][aux]<tabela[0][j]){
   printf("----|%d|",aux);
   tabela[0][j]-=aux;


}else{

}   }
}   }



          printf("|%d|----|%d|",menor_chegada,tabela[0][j]);
                            
        
        
       


    fclose(arquivo);
    return 0;
}

